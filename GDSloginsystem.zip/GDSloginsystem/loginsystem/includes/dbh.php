<?php

$dbServername = "localhost";
$dbUsername = "root";
$dbPassword = "";
$dbName = "loginsystem";

$connection = mysqli_connect($dbServername,$dbUsername, $dbPassword, $dbName);